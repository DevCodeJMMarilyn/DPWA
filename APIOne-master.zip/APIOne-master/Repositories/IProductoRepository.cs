﻿using APIOne.Models;

namespace APIOne.Repositories
{
    public interface IProductoRepository
    {
        Task<List<Producto>> ObtenerTodos();

        Task<Producto> ObtenerPorId(int id);

        Task<Producto> Crear(Producto producto);

        Task<Producto> Actualizar(Producto producto);

        Task<bool> Eliminar(int id);
    }
}
