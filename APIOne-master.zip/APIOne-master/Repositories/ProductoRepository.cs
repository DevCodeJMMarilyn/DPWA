﻿using APIOne.Data;
using APIOne.Models;
using Microsoft.EntityFrameworkCore;

namespace APIOne.Repositories
{
    public class ProductoRepository : IProductoRepository
    {
        private readonly AppDbContext _context;

        public ProductoRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Producto>> ObtenerTodos()
        {
            return await _context.Productos.ToListAsync();
        }

        public async Task<Producto> ObtenerPorId(int id)
        {
            return await _context.Productos.FindAsync(id);
        }

        public async Task<Producto> Crear(Producto producto)
        {
            _context.Productos.Add(producto);

            await _context.SaveChangesAsync();

            return producto;
        }

        public async Task<Producto> Actualizar(Producto producto)
        {
            _context.Productos.Update(producto);

            await _context.SaveChangesAsync();

            return producto;
        }

        public async Task<bool> Eliminar(int id)
        {
            var producto = await _context.Productos.FindAsync(id);

            if (producto == null)
                return false;

            _context.Productos.Remove(producto);

            await _context.SaveChangesAsync();

            return true;
        }
    }
}
