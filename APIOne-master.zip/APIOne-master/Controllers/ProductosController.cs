﻿using APIOne.Models;
using APIOne.Services;
using Microsoft.AspNetCore.Mvc;

namespace APIOne.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductosController : ControllerBase
    {
        private readonly IProductoService _service;

        public ProductosController(IProductoService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> ObtenerTodos()
        {
            var productos = await _service.ObtenerTodos();

            return Ok(productos);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> ObtenerPorId(int id)
        {
            var producto = await _service.ObtenerPorId(id);

            if (producto == null)
                return NotFound();

            return Ok(producto);
        }

        [HttpPost]
        public async Task<IActionResult> Crear(Producto producto)
        {
            var nuevo = await _service.Crear(producto);

            return Ok(nuevo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Actualizar(int id, Producto producto)
        {
            var actualizado = await _service.Actualizar(id, producto);

            if (actualizado == null)
                return NotFound();

            return Ok(actualizado);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Eliminar(int id)
        {
            var eliminado = await _service.Eliminar(id);

            if (!eliminado)
                return NotFound();

            return Ok("Producto eliminado");
        }
    }
}
