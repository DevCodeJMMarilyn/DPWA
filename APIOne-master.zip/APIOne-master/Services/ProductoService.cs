﻿using APIOne.Models;
using APIOne.Repositories;

namespace APIOne.Services
{
    public class ProductoService : IProductoService
    {
        private readonly IProductoRepository _repository;

        public ProductoService(IProductoRepository repository)
        {
            _repository = repository;
        }

        public async Task<List<Producto>> ObtenerTodos()
        {
            return await _repository.ObtenerTodos();
        }

        public async Task<Producto> ObtenerPorId(int id)
        {
            return await _repository.ObtenerPorId(id);
        }

        public async Task<Producto> Crear(Producto producto)
        {
            return await _repository.Crear(producto);
        }

        public async Task<Producto> Actualizar(int id, Producto producto)
        {
            var existente = await _repository.ObtenerPorId(id);

            if (existente == null)
                return null;

            existente.Nombre = producto.Nombre;
            existente.Precio = producto.Precio;
            existente.Stock = producto.Stock;

            return await _repository.Actualizar(existente);
        }

        public async Task<bool> Eliminar(int id)
        {
            return await _repository.Eliminar(id);
        }
    }
}
