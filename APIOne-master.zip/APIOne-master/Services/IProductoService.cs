﻿using APIOne.Models;

namespace APIOne.Services
{
    public interface IProductoService
    {
        Task<List<Producto>> ObtenerTodos();

        Task<Producto> ObtenerPorId(int id);

        Task<Producto> Crear(Producto producto);

        Task<Producto> Actualizar(int id, Producto producto);

        Task<bool> Eliminar(int id);
    }
}
